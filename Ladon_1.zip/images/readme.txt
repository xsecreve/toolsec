Ladon usage images
