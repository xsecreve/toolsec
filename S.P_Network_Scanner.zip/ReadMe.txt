
SoftPerfect Network Scanner 8.1.6

1. Open "netscan.exe" & "license.txt"

2. Copy license data

3. Paste it to license infomation tab

4. Enjoy !!!!!!!!!!!
