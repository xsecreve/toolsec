$layout_description = "Numeric Keypad"

$layout = {
						"0" => { 1 => "12"},
						"1" => { 1 => "4520"},
						"2" => { 1 => "014563"},
						"3" => { 1 => "256"},
						"4" => { 1 => "78521"},
						"5" => { 1 => "12346789"},
						"6" => { 1 => "98523"},
						"7" => { 1 => "458"},
						"8" => { 1 => "74569"},
						"9" => { 1 => "856"},
					}

# This is the furthest distance we are looking for as a jump + 1
MAX_SCORE = 2
